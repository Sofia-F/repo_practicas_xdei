IMPORTANTE

-   Para bajar la temperatura y que funcionen las suscripciones de temperatura es necesario ir a http://127.0.0.1:3000/device/monitor y ajustarlo manualmente.

-   Las gráficas pueden tardar un rato en generarse, no más de 1 minuto.